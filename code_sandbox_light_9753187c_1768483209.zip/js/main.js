/**
 * SecureShield Intel - Main JavaScript
 * Interactive functionality and dynamic content management
 */

// ===================================
// Navigation & Header
// ===================================
class Navigation {
    constructor() {
        this.header = document.getElementById('header');
        this.mobileToggle = document.querySelector('.mobile-toggle');
        this.navMenu = document.querySelector('.nav-menu');
        this.navLinks = document.querySelectorAll('.nav-link');
        
        this.init();
    }
    
    init() {
        // Scroll effect
        window.addEventListener('scroll', () => this.handleScroll());
        
        // Mobile menu toggle
        if (this.mobileToggle) {
            this.mobileToggle.addEventListener('click', () => this.toggleMobile());
        }
        
        // Smooth scroll for nav links
        this.navLinks.forEach(link => {
            link.addEventListener('click', (e) => this.handleNavClick(e));
        });
        
        // Set active link based on scroll
        window.addEventListener('scroll', () => this.updateActiveLink());
    }
    
    handleScroll() {
        if (window.scrollY > 100) {
            this.header.classList.add('scrolled');
        } else {
            this.header.classList.remove('scrolled');
        }
    }
    
    toggleMobile() {
        this.navMenu.classList.toggle('active');
        this.mobileToggle.classList.toggle('active');
    }
    
    handleNavClick(e) {
        const href = e.target.getAttribute('href');
        if (href.startsWith('#')) {
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                const offset = 80;
                const targetPosition = target.offsetTop - offset;
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                this.navMenu.classList.remove('active');
            }
        }
    }
    
    updateActiveLink() {
        const sections = document.querySelectorAll('section[id]');
        const scrollPosition = window.scrollY + 150;
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            const sectionId = section.getAttribute('id');
            
            if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
                this.navLinks.forEach(link => {
                    link.classList.remove('active');
                    if (link.getAttribute('href') === `#${sectionId}`) {
                        link.classList.add('active');
                    }
                });
            }
        });
    }
}

// ===================================
// Publications Manager
// ===================================
class PublicationsManager {
    constructor() {
        this.container = document.getElementById('publications-grid');
        this.filters = document.querySelectorAll('.publication-filters .filter-btn');
        this.publications = [];
        this.currentFilter = 'all';
        
        this.init();
    }
    
    async init() {
        this.setupFilters();
        await this.loadPublications();
    }
    
    setupFilters() {
        this.filters.forEach(btn => {
            btn.addEventListener('click', () => {
                this.filters.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.currentFilter = btn.getAttribute('data-filter');
                this.renderPublications();
            });
        });
    }
    
    async loadPublications() {
        try {
            const response = await fetch('tables/publications?limit=100&sort=-date');
            const result = await response.json();
            this.publications = result.data || [];
            this.renderPublications();
        } catch (error) {
            console.error('Error loading publications:', error);
            this.container.innerHTML = `
                <div class="loading-state">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Error al cargar las publicaciones</p>
                </div>
            `;
        }
    }
    
    renderPublications() {
        if (!this.publications.length) {
            this.container.innerHTML = `
                <div class="loading-state">
                    <i class="fas fa-inbox"></i>
                    <p>No hay publicaciones disponibles</p>
                </div>
            `;
            return;
        }
        
        const filtered = this.currentFilter === 'all' 
            ? this.publications 
            : this.publications.filter(pub => pub.category === this.currentFilter);
        
        if (!filtered.length) {
            this.container.innerHTML = `
                <div class="loading-state">
                    <i class="fas fa-search"></i>
                    <p>No se encontraron publicaciones en esta categoría</p>
                </div>
            `;
            return;
        }
        
        this.container.innerHTML = filtered.map(pub => this.createPublicationCard(pub)).join('');
    }
    
    createPublicationCard(publication) {
        const date = new Date(publication.date);
        const formattedDate = date.toLocaleDateString('es-ES', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        const categoryIcons = {
            'articulos': 'fa-newspaper',
            'analisis': 'fa-chart-line',
            'casos': 'fa-file-alt'
        };
        
        const categoryNames = {
            'articulos': 'Artículo',
            'analisis': 'Análisis Técnico',
            'casos': 'Caso de Estudio'
        };
        
        const icon = categoryIcons[publication.category] || 'fa-file';
        const categoryName = categoryNames[publication.category] || publication.category;
        
        return `
            <div class="publication-card" data-id="${publication.id}">
                <div class="publication-image">
                    <i class="fas ${icon}"></i>
                </div>
                <div class="publication-content">
                    <div class="publication-meta">
                        <span class="publication-tag">${categoryName}</span>
                        <span class="publication-date">
                            <i class="fas fa-calendar"></i> ${formattedDate}
                        </span>
                    </div>
                    <h3>${publication.title}</h3>
                    <p class="publication-excerpt">${publication.excerpt}</p>
                    <div class="publication-footer">
                        <span class="read-more">
                            Leer más <i class="fas fa-arrow-right"></i>
                        </span>
                        <span style="color: var(--text-muted); font-size: 0.875rem;">
                            <i class="fas fa-eye"></i> ${publication.views || 0} vistas
                        </span>
                    </div>
                </div>
            </div>
        `;
    }
}

// ===================================
// Products Manager
// ===================================
class ProductsManager {
    constructor() {
        this.container = document.getElementById('products-grid');
        this.filters = document.querySelectorAll('.shop-filters .filter-btn');
        this.products = [];
        this.currentFilter = 'all';
        
        this.init();
    }
    
    async init() {
        this.setupFilters();
        await this.loadProducts();
    }
    
    setupFilters() {
        this.filters.forEach(btn => {
            btn.addEventListener('click', () => {
                this.filters.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                this.currentFilter = btn.getAttribute('data-filter');
                this.renderProducts();
            });
        });
    }
    
    async loadProducts() {
        try {
            const response = await fetch('tables/products?limit=100&sort=-featured');
            const result = await response.json();
            this.products = result.data || [];
            this.renderProducts();
        } catch (error) {
            console.error('Error loading products:', error);
            this.container.innerHTML = `
                <div class="loading-state">
                    <i class="fas fa-exclamation-triangle"></i>
                    <p>Error al cargar los productos</p>
                </div>
            `;
        }
    }
    
    renderProducts() {
        if (!this.products.length) {
            this.container.innerHTML = `
                <div class="loading-state">
                    <i class="fas fa-inbox"></i>
                    <p>No hay productos disponibles</p>
                </div>
            `;
            return;
        }
        
        const filtered = this.currentFilter === 'all' 
            ? this.products 
            : this.products.filter(prod => prod.category === this.currentFilter);
        
        if (!filtered.length) {
            this.container.innerHTML = `
                <div class="loading-state">
                    <i class="fas fa-search"></i>
                    <p>No se encontraron productos en esta categoría</p>
                </div>
            `;
            return;
        }
        
        this.container.innerHTML = filtered.map(prod => this.createProductCard(prod)).join('');
    }
    
    createProductCard(product) {
        const categoryIcons = {
            'libros': 'fa-book',
            'manuales': 'fa-file-pdf',
            'guias': 'fa-map'
        };
        
        const categoryNames = {
            'libros': 'Libro',
            'manuales': 'Manual',
            'guias': 'Guía'
        };
        
        const icon = categoryIcons[product.category] || 'fa-book';
        const categoryName = categoryNames[product.category] || product.category;
        
        const formatBadge = product.format === 'digital' 
            ? '<span style="background: var(--accent-info); color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.75rem; margin-left: 0.5rem;">Digital</span>'
            : product.format === 'impreso'
            ? '<span style="background: var(--accent-success); color: white; padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.75rem; margin-left: 0.5rem;">Impreso</span>'
            : '<span style="background: var(--secondary-color); color: var(--dark-bg); padding: 0.25rem 0.5rem; border-radius: 4px; font-size: 0.75rem; margin-left: 0.5rem;">Ambos</span>';
        
        return `
            <div class="product-card" data-id="${product.id}">
                <div class="product-image">
                    <i class="fas ${icon}"></i>
                </div>
                <div class="product-content">
                    <div class="product-meta">
                        <span class="product-tag">${categoryName}</span>
                        ${formatBadge}
                    </div>
                    <h3>${product.title}</h3>
                    <p class="product-description">${product.description}</p>
                    <div style="color: var(--text-muted); font-size: 0.875rem; margin-bottom: 1rem;">
                        <i class="fas fa-user"></i> ${product.author}
                        ${product.pages ? `<span style="margin-left: 1rem;"><i class="fas fa-file-alt"></i> ${product.pages} páginas</span>` : ''}
                    </div>
                    <div class="product-footer">
                        <div class="product-price">${product.price.toFixed(2)}€</div>
                        <div class="product-actions">
                            <button class="btn-icon" title="Ver detalles" onclick="alert('Funcionalidad de compra disponible próximamente')">
                                <i class="fas fa-eye"></i>
                            </button>
                            <button class="btn-icon" title="Agregar al carrito" onclick="alert('Funcionalidad de carrito disponible próximamente')">
                                <i class="fas fa-shopping-cart"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
}

// ===================================
// Forms Manager
// ===================================
class FormsManager {
    constructor() {
        this.contactForm = document.getElementById('contact-form');
        this.newsletterForm = document.getElementById('newsletter-form');
        
        this.init();
    }
    
    init() {
        if (this.contactForm) {
            this.contactForm.addEventListener('submit', (e) => this.handleContactSubmit(e));
        }
        
        if (this.newsletterForm) {
            this.newsletterForm.addEventListener('submit', (e) => this.handleNewsletterSubmit(e));
        }
    }
    
    handleContactSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData.entries());
        
        console.log('Contact form submitted:', data);
        
        // Simulate form submission
        this.showNotification('¡Mensaje enviado correctamente! Nos pondremos en contacto contigo pronto.', 'success');
        e.target.reset();
    }
    
    handleNewsletterSubmit(e) {
        e.preventDefault();
        
        const formData = new FormData(e.target);
        const email = formData.get('email') || e.target.querySelector('input[type="email"]').value;
        
        console.log('Newsletter subscription:', email);
        
        // Simulate subscription
        this.showNotification('¡Gracias por suscribirte! Recibirás nuestras últimas publicaciones.', 'success');
        e.target.reset();
    }
    
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.style.cssText = `
            position: fixed;
            top: 100px;
            right: 20px;
            background: ${type === 'success' ? 'var(--accent-success)' : 'var(--accent-info)'};
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            box-shadow: var(--shadow-lg);
            z-index: 10000;
            animation: slideInRight 0.3s ease;
        `;
        notification.innerHTML = `
            <div style="display: flex; align-items: center; gap: 1rem;">
                <i class="fas fa-check-circle" style="font-size: 1.5rem;"></i>
                <span>${message}</span>
            </div>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease';
            setTimeout(() => notification.remove(), 300);
        }, 5000);
    }
}

// ===================================
// Animation Observer
// ===================================
class AnimationObserver {
    constructor() {
        this.observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        this.init();
    }
    
    init() {
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.animation = 'fadeInUp 0.6s ease forwards';
                    observer.unobserve(entry.target);
                }
            });
        }, this.observerOptions);
        
        // Observe elements
        const elements = document.querySelectorAll('.service-card, .publication-card, .product-card, .stat-item');
        elements.forEach(el => {
            el.style.opacity = '0';
            observer.observe(el);
        });
    }
}

// ===================================
// Initialize Application
// ===================================
document.addEventListener('DOMContentLoaded', () => {
    // Initialize all components
    new Navigation();
    new PublicationsManager();
    new ProductsManager();
    new FormsManager();
    
    // Initialize animations after a short delay to ensure content is loaded
    setTimeout(() => {
        new AnimationObserver();
    }, 500);
    
    console.log('%c🛡️ SecureShield Intel', 'font-size: 20px; font-weight: bold; color: #1a4d8f;');
    console.log('%cWebsite loaded successfully', 'font-size: 14px; color: #d4a520;');
});

// ===================================
// Utility Functions
// ===================================

// Smooth scroll to top
window.scrollToTop = function() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
};

// Format currency
window.formatCurrency = function(amount) {
    return new Intl.NumberFormat('es-ES', {
        style: 'currency',
        currency: 'EUR'
    }).format(amount);
};

// Format date
window.formatDate = function(date) {
    return new Date(date).toLocaleDateString('es-ES', {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
};
